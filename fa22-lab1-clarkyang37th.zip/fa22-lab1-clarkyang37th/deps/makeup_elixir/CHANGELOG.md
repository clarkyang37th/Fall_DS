# Changelog

<!-- %% CHANGELOG_ENTRIES %% -->

### 0.15.1 - 2021-01-29 29:28:00

Multiple bug fixes and update list of tokens.


### 0.15.0 - 2020-10-02 14:39:00

Added support for Unicode characters in identifiers (atoms and variables).
Improved handling of sigils.


### 0.14.1 - 2020-05-28 09:24:57

Handle Windows-style newlines


### 0.14.0 - 2019-07-16 22:54:32

Upgrade `:makeup` dependency to version 1.0.


### 0.13.0 - 2019-01-01 17:33:33

Register the `.ex` and `.exs` extensions as being supported by the `ElixirLexer`.


### 0.12.0 - 2018-12-30 19:12:21

Make use of Makeup's registry.


### 0.11.0 - 2018-12-22 01:26:09

Updates `makeup` dependency to 0.6.

