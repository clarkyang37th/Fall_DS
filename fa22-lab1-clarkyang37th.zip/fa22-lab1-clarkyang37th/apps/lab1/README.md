# IntroLab

Github username: (e.g., apanda)
NYU NetID: (e.g., ap191)
NYU N#:
Name: 


As a part of your handin, modify `apps/lab1/README.md` to report the
median number of retries (for 100 trials) when the drop probability is:

* 0.001 (i.e., 0.1%): 
* 0.005 (i.e., 0.5%): 
* 0.01 (i.e, 1%): 
* 0.05 (i.e., 5%): 
* 0.1 (i.e., 10%): 
* 0.2 (i.e., 20%): 
* 0.5 (i.e., 50%): 

Also report any conclusions you can draw from these observations.


# Agreement with Collaboration Policy
I [REPLACE WITH YOUR NAME] have read the course collaboration policy.

# Citations
