# Remove concurrency, enable tracing
ExUnit.start(max_cases: 1, trace: 1)
